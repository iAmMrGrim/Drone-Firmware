#!/bin/sh

channel=0
old_channel=0
wifi_channel3=0
usage()
{
	echo "There is no national domain name, and it is set to 40 channels by default!"
	return 0
}

WiFi_channel_switching()
{
	
	wifi_channel=$(fw_printenv  wifi_channel)
	#echo "old wifi_channel=$wifi_channel"
	if [ $wifi_channel -ne  $channel ];then 
		killall -9   hostapd
		sleep 1
		killall  udhcpd
		sleep  1
		ifconfig wlan0 down
		sleep  2
		if [ $channel -eq 40 ];then
			fw_setenv wifi_channel 40
		else 
			if [ $channel -eq 161 ];then
				fw_setenv wifi_channel 161
			fi
		fi
		#fw_setenv wifi_channel $channel

		
		wifi_channel=$(fw_printenv  wifi_channel)
		sed -i s/^channel=.*/channel=${wifi_channel}/ /tmp/hostapd.conf 2>/dev/null
		ifconfig wlan0 up > /dev/null
		sleep 1 
		ifconfig wlan0 172.16.10.1 netmask 255.255.0.0
		route add default gw 172.16.10.1 wlan0
		sleep 1
		hostapd  /tmp/hostapd.conf  &
		udhcpd /etc/udhcpd.conf &
	fi
}


WiFi_channel_switching2()
{
	
	#echo "old wifi_channel=$old_channel"
	if [ $old_channel -ne  $channel ];then 
		killall -9  hostapd
		sleep 1
		killall  udhcpd
		sleep  1
		ifconfig wlan0 down
		sleep  2
		wifi_channel1=$channel
		sed -i s/^channel=.*/channel=${wifi_channel1}/  /tmp/hostapd.conf 2>/dev/null
		#sed -i "s/channel.*/channel= $wifi_channel1/"  /tmp/hostapd.conf
		ifconfig wlan0 up > /dev/null
		sleep 1  
		ifconfig wlan0 172.16.10.1 netmask 255.255.0.0
		route add default gw 172.16.10.1 wlan0
		sleep  1
		hostapd  /tmp/hostapd.conf &
		udhcpd /etc/udhcpd.conf &
		old_channel=$channel
	fi
}

Shadow_SSID()
{
	killall   hostapd
	killall  udhcpd
	sleep  1
	ifconfig wlan0 down
	sleep  1
	shadow_ssid=2
	sed -i s/^ignore_broadcast_ssid=.*/ignore_broadcast_ssid=${shadow_ssid}/ /tmp/hostapd.conf 2>/dev/null

	
	sleep 1
	ifconfig wlan0 up 172.16.10.1
	hostapd  /tmp/hostapd.conf  &
	udhcpd /etc/udhcpd.conf &

}

CN_Seting()
{
		#status=`sed -n 2p /proc/net/arp`
		#sleep 2
		#status=`sed -n 2p /proc/net/arp`

		#if [ "$status" = "" ];then
		if [ ! -e /tmp/wifi_connected  ] ; then
				if [ $wifi_channel3 -eq 0 ];then
					wifi_channel3=$(fw_printenv wifi_channel)
					if [ "$wifi_channel3" = "" -o  $wifi_channel3 -lt 40 ];then
						channel=40
						fw_setenv wifi_channel 40
					fi
				fi
				if [ $wifi_channel3 -eq 40 ];then
					channel=161
					wifi_channel3=161
					WiFi_channel_switching2
					echo "---set wifi channel 161 success!"
				else 
					if [ $wifi_channel3 -eq 161 ];then
						channel=40
						wifi_channel3=40
						WiFi_channel_switching2
						echo "---set wifi channel 40 success!"
					else 
						wifi_channel3=161
						WiFi_channel_switching2
						echo "---set wifi channel 161 success!"
					fi

				fi
		else
			if [ $channel -eq 40 ];then
				fw_setenv wifi_channel 40
			else 
				if [ $channel -eq 161 ];then
					fw_setenv wifi_channel 161
				fi
			fi
			echo "wifi connected!"	
			#while true
			#do
			#	SHadow_mac_find	
			#	sleep 3
			#done
			exit 1
		fi

}


US_Seting()
{
		
		if [ $set_success -eq 0 ];then
			#echo "set National_standard us!"
			set_success=1
			channel=161           
			WiFi_channel_switching

		fi
		while true
		do
			read_count=$(($read_count+1))
			#echo "read_count=$read_count"
			status=`sed -n ''$read_count','$read_count'p' /proc/net/arp` 
			if [ "$status" = "" ];then
				read_count=1
				break;
			else
				mac=${status:41:8}
				#echo "mac=$mac"
				if [ "$mac" = "b2:41:1d" -o  "$mac" = "b0:41:1d"  -o "$mac" = "38:e2:6e" ];then
					echo "begin shadow_ssid"
					Shadow_SSID
					echo "end Shadow_ssid"
					read_count=1
					exit 1

				fi
			fi

		done

}



SHadow_mac_find()
{

		while true
		do
			#read_count=`expr $read_count + 1`
			read_count=$(($read_count+1)) 
			#echo "read_count=$read_count"
			status=`sed -n ''$read_count','$read_count'p' /proc/net/arp` 
			if [ "$status" = "" ];then
				read_count=1
				break;
			else
				mac=${status:41:8}
				#mac=3a:e2:6e
				#echo "mac=$mac"
				if [ "$mac" = "b2:41:1d"  -o  "$mac" = "b0:41:1d"  -o  "$mac" = "38:e2:6e"  -o  "$mac" = "3a:e2:6e" ];then
					echo "begin shadow_ssid"
					Shadow_SSID
					echo "end Shadow_ssid"
					echo 1 > /tmp/shadow_ssid
					read_count=1
					exit 1

				fi
			fi

		done

}


Channel_setting()
{
	case "$National_standard" in
		cn)
			CN_Seting         #�й�#
			;;
		us)
			US_Seting	  #����#
			
			;;
		ca)	
			channel=161       #���ô�#
			WiFi_channel_switching
			exit 1
			;;
		ru)	
			channel=161           #����˹#
			WiFi_channel_switching
			exit 1
			;;
		sg)	
			channel=161            #�¼���#
			WiFi_channel_switching
			exit 1
			;;
		tw)	
			channel=161             #�й�̨��#
			WiFi_channel_switching
			exit 1
			;;
		kr)	
			channel=161              #����#
			WiFi_channel_switching
			exit 1
			;;
		au)	
			channel=161              #�Ĵ�����#
			WiFi_channel_switching
			exit 1
			;;
		za)	
			channel=100               #�Ϸ�#
			WiFi_channel_switching
			exit 1
			;;
		br)	
			channel=161                #����#
			WiFi_channel_switching
			exit 1
			;;
		nz)	
			channel=161               #������#
			WiFi_channel_switching
			exit 1
			;;
		is)	
			channel=40                #���� #
			WiFi_channel_switching
			exit 1
			;;
		in)	
			channel=40                # ӡ��#
			WiFi_channel_switching
			exit 1
			;;
		id)	
			channel=161              #ӡ��������#
			WiFi_channel_switching
			exit 1
			;;
		ir)	
			channel=161              #����#
			WiFi_channel_switching
			exit 1
			;;
		iq)	
			channel=161              #������#
			WiFi_channel_switching
			exit 1
			;;
		ie)	
			channel=40              #������#
			WiFi_channel_switching
			exit 1
			;;
		it)	
			channel=40             #�����#
			WiFi_channel_switching
			exit 1
			;;
		jo)	
			channel=40              #Լ��#
			WiFi_channel_switching
			exit 1
			;;
		lv)	
			channel=40             #����ά��#
			WiFi_channel_switching
			exit 1
			;;
		lb)	
			channel=161             #�����#
			WiFi_channel_switching
			exit 1
			;;
		li)	
			channel=40            #��֧��ʿ��#
			WiFi_channel_switching
			exit 1
			;;
		lt)	
			channel=40             #������#
			WiFi_channel_switching
			exit 1
			;;
		lu)	
			channel=40              #¬ɭ��#
			WiFi_channel_switching
			exit 1
			;;
		mo)	
			channel=161             #����#
			WiFi_channel_switching
			exit 1
			;;
		mk)	
			channel=40               #�����#
			WiFi_channel_switching
			exit 1
			;;			
		my)	
			channel=161              #��������#
			WiFi_channel_switching
			exit 1
			;;	
		mt)	
			channel=40               #������#
			WiFi_channel_switching
			exit 1
			;;
		mx)	
			channel=161                #ī����#
			WiFi_channel_switching
			exit 1
			;;	
		mc)	
			channel=40            #Ħ�ɸ�#
			WiFi_channel_switching
			exit 1
			;;
		nl)	
			channel=40         #����#
			WiFi_channel_switching
			exit 1
			;;
		eu)	
			#ŷ��#
			channel=40    
			WiFi_channel_switching
			exit 1
			;;
		ch)	
			#��ʿ#
			channel=40    
			WiFi_channel_switching
			exit 1
			;;
		jp)	
			#�ձ�#
			channel=40    
			WiFi_channel_switching
			exit 1
			;;
		il)	
			#��ɫ��#
			channel=40    
			WiFi_channel_switching
			exit 1
			;;
		tr)	
			#������#			
			channel=40    
			WiFi_channel_switching
			exit 1
			;;
		kz)	
			#������˹̹#
			channel=40    
			WiFi_channel_switching
			exit 1
			;;
		kw)	
			#������#
			channel=40    
			WiFi_channel_switching
			exit 1
			;;
		ma)	
			#Ħ���#
			channel=40    
			WiFi_channel_switching
			exit 1
			;;		
		*)
			usage
			channel=40  
			#WiFi_channel_switching
			CN_Seting
			#exit 1
			;;
	esac

}



times_count=0
read_count=1
set_success=0
old_channel=$(fw_printenv  wifi_channel)
check_count=0
#cp  /netPrivate/hostapd.conf /tmp/hostapd.conf  -rf
sleep 10
CN_Seting
while true
do
	#SHadow_mac_find
	while true
	do 
		sleep 2
		#SHadow_mac_find
		#check_count=`expr $check_count + 1`
		check_count=$(($check_count+1)) 
		if [ $check_count -gt 10 ];then
			check_count=0
			break;
		fi
	done
	National_standard=$(fw_printenv  country_code)
        echo "National_standard=$National_standard"	
	Channel_setting
	
	sleep 1
done
