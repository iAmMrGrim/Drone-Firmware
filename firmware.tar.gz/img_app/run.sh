#!/bin/ash

#echo "/mnt/corefile/core-%e-%p-%t" > /proc/sys/kernel/core_pattern
#echo 1 > /proc/sys/kernel/core_uses_pid
#ulimit -c unlimited
#mkdir corefile

TARGET=VideoTransmission
PWD=$(pwd)
#chmod 755 ./bin/$TARGET
export LD_LIBRARY_PATH=$PWD/lib/:$LD_LIBRARY_PATH
./bin/$TARGET &
#pilot &
