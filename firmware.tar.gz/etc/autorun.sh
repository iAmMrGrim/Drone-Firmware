#!/bin/sh


mount_partition()
{
	echo "mount $1 partition"
	mount /dev/mtdblock4 $1 
	if [ $? -ne 0 ];then
		echo "mount $1 partition fail,format partition !"
		for n in `seq 1 3`
		do
			mkfs.vfat /dev/mtdblock4
			if [ $? -eq 0 ];then
				mount /dev/mtdblock4 $1
				break;
			fi
		done
	fi
}

usb_mass_storage()
{
	echo 0 > /sys/class/android_usb/android0/enable
	echo 18d1 > /sys/class/android_usb/android0/idVendor
	echo 0001 > /sys/class/android_usb/android0/idProduct
	echo mass_storage > /sys/class/android_usb/android0/functions
	echo /dev/mmcblk0 > /sys/class/android_usb/android0/f_mass_storage/lun/file
	echo 1 > /sys/class/android_usb/android0/enable
}
#echo 8 > /proc/sys/kernel/printk	A
MODULES_DIR=/lib/modules/`uname -r`
#insmod ${MODULES_DIR}/compat.ko &&  insmod ${MODULES_DIR}/cfg80211.ko && insmod ${MODULES_DIR}/ath6kl_usb.ko && mount /dev/mtdblock5 /netPrivate && #/etc/wifi_switch.sh
#insmod ${MODULES_DIR}/xradio_mac.ko &&  insmod ${MODULES_DIR}/xradio_core.ko && insmod ${MODULES_DIR}/xradio_wlan.ko 
#insmod ${MODULES_DIR}/compat.ko && insmod ${MODULES_DIR}/cfg80211.ko && insmod ${MODULES_DIR}/ath6kl_usb.koi
mount_partition /netPrivate
cp /etc/ssv6x5x-wifi.cfg  /netPrivate/
insmod ${MODULES_DIR}/cfg80211.ko  && insmod ${MODULES_DIR}/mac80211.ko  && insmod ${MODULES_DIR}/ssv6x5x.ko  stacfgpath=/netPrivate/ssv6x5x-wifi.cfg
sleep 1
cd /lib/modules/3.4.39-rt143/
insmod videobuf-core.ko
insmod videobuf-dma-contig.ko
insmod vfe_os.ko
insmod vfe_subdev.ko
insmod cci.ko
insmod h62_mipi.ko
insmod f23_mipi.ko
insmod f28_mipi.ko
insmod s5k3h7.ko
insmod imx175.ko
insmod bf3a03.ko
insmod gc0328.ko
insmod gc0308.ko
insmod sp0a20.ko
insmod vfe_v4l2.ko
#ifconfig wlan0 up
/etc/wifi_switch.sh
#sunxi_poweroff_detection
#usb_mass_storage
cd /img_app
nice --19 ./run.sh

/etc/flow &
#cd /etc/init.d/
#./adbd.init &

cd /
#pilot &
