#!/bin/sh
#if [ $1 == "up" ]
#then
ifconfig wlan0 up > /dev/null 
sleep 1
ifconfig wlan0 172.16.10.1 netmask 255.255.0.0
route add default gw 172.16.10.1 wlan0
#exit 1
if [ -e "/netPrivate/ssid_set" ];
then
	echo "------------------***********start hostapd"
	cp /etc/hostapd.conf  /tmp/  -rf
	cp /etc/hostapd_24g.conf  /tmp/  -rf
	hw=`wifi_ssid_get`
	if [ -f /netPrivate/ssid_set  ] ; then
		/etc/setssid  $hw
		#rm /netPrivate/ssid_set  -rf
	fi
	if [ -f /netPrivate/channel_set  ] ; then
		/etc/setchannel
		#rm /netPrivate/channel_set  -rf
	fi
	hostapd /tmp/hostapd.conf  &
	#hostapd /tmp/hostapd_24g.conf  &
else
	#cp /etc/ssv6x5x-wifi.cfg  /netPrivate/  -rf
	cp /etc/hostapd.conf  /tmp/  -rf
	cp /etc/hostapd_24g.conf  /tmp/  -rf
#	MAC=$(cat /sys/class/net/wlan0/address|sed 's/://g')
#	hw=$(echo ${MAC:6})
	hw=`wifi_ssid_get`
	#echo $hw  >  /netPrivate/ssid_mowei
	echo "----------------------------------hw=$hw"
#	sed -i "s/^ssid=.*$/ssid=VSLCAM-$hw/g" /tmp/hostapd.conf
#	sed -i "s/^ssid=.*$/ssid=VSLCAM-$hw/g" /tmp/hostapd_24g.conf
	sed -i "s/^ssid=.*$/ssid=LULA-5G-WS8K-$hw/g" /tmp/hostapd.conf
	if [ -f /netPrivate/channel_set  ] ; then
		/etc/setchannel
	fi
	hostapd /tmp/hostapd.conf &
#	hostapd /tmp/hostapd_24g.conf  &
	#sync
	#blockdev --flushbufs /dev/mtdblock4
fi

if [ ! -e "/netPrivate/config.ini" ];
then
	cp /etc/ssv6x5x-wifi.cfg  /netPrivate/  -rf
	cp /img_app/bin/config.ini /netPrivate/  -rf
	sync
	blockdev --flushbufs /dev/mtdblock4
fi

if [ ! -e "/netPrivate/config.dat" ];
then
	cp /etc/config.dat /netPrivate
fi

if [ ! -e "/netPrivate/save.sh" ];
then
	cp /etc/save.sh /netPrivate
fi

#sync 
#blockdev --flushbufs /dev/mtdblock4

udhcpd /etc/udhcpd.conf > /dev/null 
ftpd  -f /etc/ftpd.conf > /dev/null
#elif [ $1 == "down" ]
#then
#kill `pidof ftpd`
#kill `pidof udhcpd`
#kill `pidof hostapd`
#ifconfig wlan0 down

#elif [ $1 == "get_status" ]
#then
#ifconfig -a | grep "mon.wlan0" > /dev/null
#echo "$?"
#fi
mount -t debugfs none /proc/sys/debug/
telnetd &
#cp /netPrivate/hostapd.conf  /tmp/hostapd.conf -f
wifi-switch_2.sh &
