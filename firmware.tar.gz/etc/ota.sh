#!/bin/sh

ENV_PATH=/dev/mtd3
KERNEL_PATH=/dev/mtd1
ROOTFS_PATH=/dev/mtd2
KERNEL_BACKUP_PATH=/dev/mtd5
ROOTFS_BACKUP_PATH=/dev/mtd6
FIRMWARE_PATH=/tmp
MASTER_ROOT_WAY="mtdblock2"
BACKUP_ROOT_PARTITION="mtdblock6"
MASTER_KERNEL_WAY="boot_normal"
KERNEL_IMG="uImage"
ROOTFS_IMG="rootfs.squashfs"
TMP_PATH=${FIRMWARE_PATH}/ota_update_allwinnertech
ENV_TMP_PATH="/tmp/env.fex" 
CURRENT_ROOT_PARTITION=
CURRENT_KERNEL_WAY=
update=0
ENV_SIZE_KB=128

get_env()
{
	dd if=${ENV_PATH} of=${ENV_TMP_PATH} bs=1024 count=${ENV_SIZE_KB}
	if [ $? = 0 ] ; then
		CURRENT_ROOT_PARTITION=`cat ${ENV_TMP_PATH} | grep ^nand_root= | awk -F "=" '{print $2}' | awk -F "/" '{print $3}'` 
		CURRENT_KERNEL_WAY=`cat ${ENV_TMP_PATH} | grep ^bootcmd= | awk -F " " '{print $3}'`
	else
		echo "get_env: dd failed!"
		return 1
	fi
}

set_env()
{
	if [ "$1" = "rootfs" ] ; then
		if [ ${CURRENT_ROOT_PARTITION} = ${MASTER_ROOT_WAY} ] ; then
				sed -i 's/^nand_root=.*$/nand_root=\/dev\/mtdblock6/' ${ENV_TMP_PATH}
		else
				sed -i 's/^nand_root=.*$/nand_root=\/dev\/mtdblock2/' ${ENV_TMP_PATH} 
		fi
	elif [ "$1" = "kernel" ] ; then
		if [ ${CURRENT_KERNEL_WAY} = ${MASTER_KERNEL_WAY} ] ; then
			sed -i 's/^bootcmd=.*$/bootcmd=run setargs_nand boot_recovery/' ${ENV_TMP_PATH}
		else
			sed -i 's/^bootcmd=.*$/bootcmd=run setargs_nand boot_normal/' ${ENV_TMP_PATH}
		fi
	fi
}

save_env()
{
	local ENV_BACKUP_PATH="/dev/mtd7"
	if [ -e ${ENV_TMP_PATH} ] ; then
		flash_erase ${ENV_BACKUP_PATH} 0 0 > /dev/null
		dd if=${ENV_PATH} of=${ENV_BACKUP_PATH} bs=1024 count=${ENV_SIZE_KB}
		if [ $? = 0 ] ; then
			sunxi_env_gen ${ENV_TMP_PATH} /tmp/env-ota.fex
			flash_erase ${ENV_PATH} 0 0 > /dev/null
			dd if=/tmp/env-ota.fex of=${ENV_PATH} bs=1024 count=${ENV_SIZE_KB}
		else
			echo "save_env: dd failed!"
			return 1
		fi
	fi
}

rootfs_burn()
{
	local ROOTFS_OTA_PATH
	if [ -e ${TMP_PATH}/${ROOTFS_IMG} ] ; then
		if [ ${CURRENT_ROOT_PARTITION} = ${MASTER_ROOT_WAY} ] ; then
			ROOTFS_OTA_PATH=${ROOTFS_BACKUP_PATH}
		else
			ROOTFS_OTA_PATH=${ROOTFS_PATH}
		fi
		
		echo "rootfs ${ROOTFS_OTA_PATH} burning..."
		flash_erase ${ROOTFS_OTA_PATH} 0 0 > /dev/null
		dd if=${TMP_PATH}/${ROOTFS_IMG} of=${ROOTFS_OTA_PATH}
		if [ $? = 0 ] ; then
			set_env "rootfs"
			update=1
		else
			echo "rootfs_burn: dd failed!"
			return 1
		fi
	fi
}

kernel_burn()
{
	local KERNEL_OTA_PATH
	
	if [ -e ${TMP_PATH}/${KERNEL_IMG} ] ; then
		if [ ${CURRENT_KERNEL_WAY} = ${MASTER_KERNEL_WAY} ] ; then
			KERNEL_OTA_PATH=${KERNEL_BACKUP_PATH}
		else
			KERNEL_OTA_PATH=${KERNEL_PATH}
		fi
		
		echo "kernel ${KERNEL_OTA_PATH} burning..."
		flash_erase ${KERNEL_OTA_PATH} 0 0 > /dev/null
		dd if=${TMP_PATH}/${KERNEL_IMG} of=${KERNEL_OTA_PATH}
		if [ $? = 0 ] ; then
			set_env "kernel"
			update=1
		else
			echo "kernel_burn: dd failed!"
			return 1
		fi
	fi
}


firmware_burn()
{
	local md5

	#md5=`md5sum ${FIRMWARE_PATH}/$1.zip | awk -F " " '{print $1}'` 
	#if [ "x${md5}" = "x$2" ] ; then
		#killall -q pilot flow
		mkdir -p ${TMP_PATH}
		unzip ${FIRMWARE_PATH}/$1.zip -d ${TMP_PATH}
		if [ $? = 0 ] ; then
			if [ -e ${TMP_PATH}/${KERNEL_IMG} ] &&  [ -e ${TMP_PATH}/${ROOTFS_IMG} ] ; then
				rm -f ${FIRMWARE_PATH}/$1.zip
				get_env && rootfs_burn && kernel_burn
			else 
				if [ -e ${TMP_PATH}/${KERNEL_IMG}   ] ; then
					get_env && kernel_burn
				else
					if [  -e ${TMP_PATH}/${ROOTFS_IMG} ] ; then
						get_env && rootfs_burn 
					fi
				fi
			fi
		else
			rm -rf ${TMP_PATH}
			echo "firmware_burn: unzip firmware failed!"
			return 1
		fi
		if [ $update -eq 1 ] ; then
			save_env
			sync
			rm -rf /mnt/rootfs.squashfs  -rf
			rm -rf /mnt/uImage  -rf
			rm -rf ${TMP_PATH}  -rf
			
		else
			rm -rf ${TMP_PATH}
			echo "firmware_burn:  nothing to burn!"
			return 1
		fi
	#else
	#	echo "md5 error!"
	#	return 1
	#fi
}


firmware_burn $@
